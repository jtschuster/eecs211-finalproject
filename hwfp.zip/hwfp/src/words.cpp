#include "controller.h"

#include <stdexcept>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {

    Controller().run();

}
